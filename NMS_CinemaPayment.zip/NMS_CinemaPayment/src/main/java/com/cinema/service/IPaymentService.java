package com.cinema.service;

import java.util.List;

import com.cinema.domain.Payment;



public interface IPaymentService {
	Payment save(Payment payment);
	Payment update(Payment payment);
	void delete(Integer id);
	List<Payment> getAllPayments();
	Payment getPaymentsById(Integer id);
	List<Payment> getAllPaymentByDate(String date);
	List<Payment> getAllPaymentByAmount(String amount);
}
